# DESY P65 column compatibility

The local reference collection was audited across 2020–2026.

- 201 measurement files tested
- 137 XDI files and 64 DAT files
- 14 distinct column schemas
- 201 files recognized as PETRA III P65
- 201 files successfully processed with the schema-aware default column selection

## Automatic defaults

| File family | Energy | Signal | Calculation |
| --- | --- | --- | --- |
| Modern raw P65 | `energy_enc` or `e_enc` | `i1`, `i2` | `I1 / I2` |
| Legacy P65 | `mono_energy` | `vfc02`, `vfc03` | `ln(VFC02 / VFC03)` |
| Processed XDI | `energy` | `murefer` | Direct column |
| Two-column reference | `energy` | `_ev` | Direct column |

The verification page lets the user change these choices and preview the result. When **Use this column selection for QC** is enabled, the selected columns and calculation are used by the original QC engine and stored in the dataset metadata.

The automatic beamline reader remains available by clearing that checkbox.
