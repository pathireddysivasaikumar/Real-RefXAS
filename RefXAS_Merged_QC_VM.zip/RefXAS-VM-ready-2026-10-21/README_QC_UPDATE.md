# RefXAS QC update for local testing

This ZIP contains the entire uploaded `Real-RefXAS-integrated-refxas-2026` project.
The uploaded `quality_check.py` has been placed in `quality_control/`, then
corrected for automatic edge finding. The original `Criteria.json`,
`Criteria_json.py`, `data_check.py`, and all reference measurements remain in
their project locations. This package has not been deployed to the KIT VM.

## What changed

- `plugins/read_data.py` now matches beamline header markers regardless of one
  or two spaces. It also selects the matching synchrotron or laboratory reader,
  so TU Berlin files are recognized without a prior source choice. Unknown
  files with more than two columns stop with an error instead of silently using
  the first two columns.
- `quality_control/quality_check.py` uses the strongest derivative peak for
  automatic E0. The previous code chose the last surviving peak, even when it
  was much weaker. QC still uses Larch to map E0 to an element and edge.
- The upload page detects element and edge before verification and preselects
  both values in the form. Users can still override them. QC rejects a manual
  mismatch greater than 100 eV. A manual `M4,5` choice resolves to the closer
  M4 or M5 edge.
- The verification page includes an Athena-style column preview. Users can
  select the energy and signal columns, compare raw/ratio/log calculations,
  and review basic data suitability indicators before submitting the dataset.
- The upload integration now passes the form's source type to the reader.

## Local QC test on Windows

1. Extract this entire ZIP. Install 64-bit Python 3.12 with the `py` launcher.
2. Double-click `SETUP_ONCE.bat` in the extracted project root. This installs
   Larch and other QC libraries into a local `.venv` folder using
   `qc_local_requirements.txt`. Internet access is needed once. The project's
   root `requirements.txt` belongs to the full historical web deployment;
   the local QC setup does not use it.
3. Open Command Prompt in the project root and run:

   ```bat
   RUN_QC.bat "quality_control\example data\SYNCHROTRON\Fe_foil_Fe_K_300.xdi"
   ```

   For your own file or a folder of measurements, replace the quoted path.
   Results are written to `results\qc_summary.csv` and four plot folders.
   `REVIEW` means that QC processed the file but at least one criterion failed;
   `ERROR` means processing failed. The Fe example can legitimately report
   `REVIEW` under the existing acceptance limits.

4. For laboratory files, run:

   ```powershell
   .\RUN_QC.ps1 -InputPath 'quality_control\example data\LABORATORY\CoO powder.dat' -Facility LABORATORY
   ```

   `-TakeFirst` selects the first derivative peak instead of the strongest;
   `-NoPlots` skips PNGs. The `quality_check.py` direct-run example contains
   historical machine-specific paths, so use these helpers for local testing.

The automated regression tests are in `test/test_qc_regression.py`. They cover
single-space beamline headers, real SAMBA and TU Berlin files, safe rejection
of unknown multi-column files, E0 selection, manual edge validation, and
reference foil recognition. Run them inside the installed environment with
`.\.venv\Scripts\python.exe -m unittest test.test_qc_regression -v`.

The supplied DELTA example has no beamline header, so it remains a generic
two-column read. Single-space DELTA headers are covered by the regression test.

Local QC tests do not exercise SciCat, the web upload, or the KIT VM. Those
services require their deployment configuration and credentials.
