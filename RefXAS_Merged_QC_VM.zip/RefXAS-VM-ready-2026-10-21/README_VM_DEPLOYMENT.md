# RefXAS VM release candidate — 21 October 2026

This package combines Sebastian's `qc-merge-2026-10-06` VM baseline with the
current RefXAS QC, beamline reader, column-selection, curator and local-testing
work. It is designed to build the RefXAS application image directly from this
source tree so Docker cannot silently reuse the previous `latest` image.

## Included from Sebastian's VM package

- The merged QC baseline and known beamline markers.
- The curator fix that filters published datasets before display and shows all
  pending datasets on one page.
- The QC before/after regression runner in `quality_control/regression/`.
- The MkDocs sources and generated project documentation.

## Additional functionality retained

- General single/double-space beamline-header normalization.
- P64 numbered-column support.
- HDF5/NeXus and extensionless HDF5 recognition.
- Interactive Energy, Signal A, Signal B and calculation selection.
- Unchecked-by-default main-spectrum selection.
- Selected-spectrum CSV download and upload beside the original file.
- Improved element/edge handling, curator details and binary-safe ZIP exports.
- Windows standalone QC helpers and the focused regression test suite.

## Before deployment

Do not copy credentials from this ZIP into Git. On the VM, create the runtime
files from the provided templates and replace every `CHANGE_ME` value:

```bash
cp .env.vm.example .env
cp xafsdb_deployment/config/backend/config.example.env \
   xafsdb_deployment/config/backend/config.env
cp xafsdb_deployment/config/backend/functionalAccounts.example.json \
   xafsdb_deployment/config/backend/functionalAccounts.json
cp xafsdb_deployment/config/xafsdb/_auth_constants.example.py \
   xafsdb_deployment/config/xafsdb/_auth_constants.py
```

Use the existing VM values where appropriate. `DB_PASSWORD` in `.env` is used
by both PostgreSQL and Django. The SciCat password in `.env`,
`functionalAccounts.json` and `_auth_constants.py` must agree.

## Safe deployment sequence

1. Back up the existing VM project directory.
2. Back up the PostgreSQL and MongoDB data/volumes.
3. Record the currently running image IDs with `docker compose images`.
4. Extract this package into a new release directory, not over the live folder.
5. Create the four runtime configuration files listed above.
6. Run the static checks:

   ```bash
   python scripts/validate_integration.py
   docker compose --env-file .env \
     -f xafsdb_deployment/docker-compose.yaml config --quiet
   ```

7. Build without replacing the live service:

   ```bash
   docker compose --env-file .env \
     -f xafsdb_deployment/docker-compose.yaml build xafsdb
   ```

8. Start during a maintenance window:

   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

9. Verify `/`, `/dataset/upload_view`, login, a representative P65 upload, a
   P64 DAT upload, selected-spectrum CSV download, curator review and dataset
   ZIP download.

## Important status

This package is a **VM release candidate**. Its source and Compose configuration
are prepared for deployment, but it must pass the VM/staging checks above before
being treated as the production release. Existing VM secrets and persistent
database volumes are deliberately not included.

## Validation completed before packaging

- Static integration validation: passed (144 Python files compiled).
- Production Compose configuration: passed using the supplied templates.
- Docker image build: passed as `refxas-vm:2026-10-21`.
- Django `manage.py check`: passed with no issues.
- Focused QC regression suite: 13 tests passed.
- Sebastian's example-file runner processed 43 files. One Pd example was
  deliberately stopped by the newer safety check because its detected E0 was
  more than 100 eV from the requested Pd K edge; the other 42 produced results.
