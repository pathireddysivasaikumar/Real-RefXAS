# Release validation record

Date: 21 October 2026

| Check | Result |
|---|---|
| Static Python/integration validation | PASS — 144 Python files compiled |
| Docker Compose configuration | PASS with template configuration |
| Docker image build | PASS — `refxas-vm:2026-10-21` |
| Django system check | PASS — no issues |
| Focused QC regression tests | PASS — 13 of 13 |
| Sebastian example-file runner | 43 processed; 42 results, 1 intentional E0 safety rejection |

The rejected example is `Pd_foil_Up_av700_00001.txt`. Its detected E0 was
24238 eV, more than 100 eV from the Pd K edge at 24350 eV. The candidate stops
instead of silently accepting that mismatch.

This validation does not replace a staging/VM test with the real SciCat, S3,
SMTP, DNS/TLS and persistent database configuration.
