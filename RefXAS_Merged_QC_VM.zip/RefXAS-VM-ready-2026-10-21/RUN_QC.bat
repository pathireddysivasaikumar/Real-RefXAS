@echo off
if "%~1"=="" (
    echo Usage: RUN_QC.bat "C:\path\to\measurement-file-or-folder" ["C:\path\to\results"]
    pause
    exit /b 2
)
if "%~2"=="" (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_QC.ps1" -InputPath "%~1"
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_QC.ps1" -InputPath "%~1" -OutputPath "%~2"
)
if errorlevel 1 (
    echo QC encountered an error. Check results\qc_summary.csv.
    pause
    exit /b 1
)
pause
