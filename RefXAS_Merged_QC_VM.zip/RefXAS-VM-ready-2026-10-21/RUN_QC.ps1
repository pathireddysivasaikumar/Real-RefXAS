param(
    [Parameter(Mandatory=$true, Position=0)] [string] $InputPath,
    [Parameter(Position=1)] [string] $OutputPath = 'results',
    [ValidateSet('SYNCHROTRON', 'LABORATORY')] [string] $Facility = 'SYNCHROTRON',
    [switch] $TakeFirst,
    [switch] $NoPlots
)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) {
    throw 'Run SETUP_ONCE.bat first.'
}

$arguments = @('run_qc.py', $InputPath, '--output', $OutputPath, '--facility', $Facility)
if ($TakeFirst) { $arguments += '--take-first' }
if ($NoPlots) { $arguments += '--no-plots' }
& $python @arguments
exit $LASTEXITCODE
