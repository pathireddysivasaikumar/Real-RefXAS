$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

$launcher = Get-Command py -ErrorAction SilentlyContinue
if (-not $launcher) {
    throw 'Python launcher (py) was not found. Install 64-bit Python 3.12 from python.org, then rerun SETUP_ONCE.bat.'
}

& py -3.12 -c 'import sys; print(sys.version)' | Out-Host
if ($LASTEXITCODE -ne 0) {
    throw 'Python 3.12 was not found. Install 64-bit Python 3.12, then rerun SETUP_ONCE.bat.'
}

if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
    & py -3.12 -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the local Python environment.' }
}

$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'Could not upgrade pip.' }
& $python -m pip install -r qc_local_requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
& $python -c 'import larch, numpy, scipy, matplotlib, PIL, h5py; from quality_control.quality_check import CheckQualityControl; from plugins.read_data import ReadData'
if ($LASTEXITCODE -ne 0) { throw 'QC dependency check failed.' }

Write-Host 'QC imports OK'
Write-Host 'Setup complete. Run RUN_QC.bat with a measurement file or folder.'
