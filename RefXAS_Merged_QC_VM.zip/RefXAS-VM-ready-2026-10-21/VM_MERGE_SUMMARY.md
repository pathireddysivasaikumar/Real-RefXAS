# Merge summary

- Base: current `Real-RefXAS-integrated-refxas-2026` working directory.
- Imported: Sebastian's `docs/`, `mkdocs/` and
  `quality_control/regression/` content.
- Restored: Sebastian's curator pending-dataset filtering and single-page list.
- Preserved: all newer reader, QC, column-selection, upload and curator-detail
  improvements from the working directory.
- Deployment: Compose now builds this source tree as
  `refxas-vm:2026-10-21`, loads `.env`, uses one `DB_PASSWORD`, disables the
  insecure Traefik API and mounts the Docker socket read-only.
- Security: runtime secrets, local databases, logs, media, static build output
  and caches are excluded from the package and Docker build context.
