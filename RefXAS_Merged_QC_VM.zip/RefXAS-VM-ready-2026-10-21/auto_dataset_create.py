"""
auto_dataset_create.py
-----------------------
@author: Sebastian Paripsa
@email: paripsa@uni-wuppertal.de (or: sebastian.paripsa@gmail.com)
@linkedin: https://www.linkedin.com/in/sebastian-paripsa/
@git: https://github.com/San-WierPa

Description:
------------
This script automates the process of dataset creation by using the SciCat API.
It performs tasks such as data reading, quality control checks, and finally,
uploads the dataset to the designated repository.

SEO Tags:
---------
#SciCat #DatasetAutomation #Python #DataScience

Modules:
--------
- read_data: Reads the raw data files
- check_quality: Performs quality control on the dataset
- scicat_py: SciCat's Python API

Requirements:
-------------
- Python 3.10
- SciCat API access

"""

from __future__ import print_function
import json
import io
from datetime import datetime
from django.core.mail import send_mail
from sys import path
from typing import Optional, NoReturn
import environ
import numpy as np
import pyshorteners
import requests
import scicat_py
from webserver.settings import EMAIL_HOST_USER, EMAIL_NOTIFICATIONS_ENABLED
from quality_control.quality_check import check_quality
from plugins.read_data import ReadData
from typing import Dict, Any
import logging
from pathlib import Path

env = environ.Env()
environ.Env.read_env()

prefix = env("PREFIX")
SCICAT_API_URL = env("SCICAT_API_URL", default="http://scicat:3000")
XAFSDB_INTERNAL_URL = env("XAFSDB_INTERNAL_URL", default="http://127.0.0.1:8000")

class AutoDatasetCreation(object):
    """
    This class automatically creates, respectively updates a dataset,
    does the quality_control and serves all to the webserver
    """
    def __init__(self, s3_data_path, data_set_name, verify_data):
        self.data_set_name = data_set_name
        #print("data_set_name:", data_set_name)
        self.s3_data_path = s3_data_path
        #print("s3_data_path:", s3_data_path)
        self.verify_data = verify_data

        #print("Dataset creation initialized...how exciting!")
        self.configuration = scicat_py.Configuration(
            # VM/container-safe endpoint. Override with SCICAT_API_URL if needed.
            host=SCICAT_API_URL,
        )
        self.qc_path = "quality_control/"
        path.append(self.qc_path)
        self.auth_login()
        self.create_testdata()
        self.post_sthree()
        self.short_url()
        self.qc_and_update()
        self.upload_figure_data(figure=self.data_dict["scientific_metadata"]["Figures"]["raw_data"],
                                caption="Raw data")
        self.upload_figure_data(figure=self.data_dict["scientific_metadata"]["Figures"]["normalized_data"],
                                caption="Normalized data")
        self.upload_figure_data(figure=self.data_dict["scientific_metadata"]["Figures"]["k"],
                                caption="k")
        self.upload_figure_data(figure=self.data_dict["scientific_metadata"]["Figures"]["R"],
                                caption="R")

    def auth_login(self) -> Optional[str]:
        """
        Authenticates with the SciCat API by logging in with provided credentials
        and retrieves an access token for subsequent requests.

        Returns:
            The access token string or None (hence the Optional[str]) if there was an error
        """
        with scicat_py.ApiClient(configuration=self.configuration) as api_client:
            api_instance = scicat_py.AuthApi(api_client)
            credentials_dto = scicat_py.CredentialsDto(
                username=env("USERNAME_AUTH"),
                password=env("PASSWORD_AUTH"),
            )
            api_response = api_instance.auth_controller_login(credentials_dto)
            self.access_token = api_response["access_token"]
            print("SciCat authentication successful")
            return self.access_token

    def create_testdata(self) -> Optional[str]:
        """
        Creates a new test dataset and returns its ID.

        Returns:
            str or None: The ID of the created dataset or None if an error occurred.
        """
        titlename = self.data_set_name
        self.data_dict = {
            "owner_group": self.verify_data.get("Owner group"),
            "access_groups": "NO_THUMBNAIL",
            "creation_location": "wuppertal",
            "principal_investigator": "someone",
            "dataset_name": titlename
            + " "
            + datetime.now().strftime("%Y-%m-%d-%H_%M_%S"),
            "type": "raw",
            "is_published": False,
            "creation_time": str(datetime.now().isoformat()),
            "source_folder": "None",
            "owner": self.verify_data.get("Owner"),
            "contact_email": self.verify_data.get("Contact email"),
            "scientific_metadata": {
                "Description": self.verify_data.get("Description"),
                "Data": {
                    "Source": self.verify_data.get("Source"),
                    "Mode": self.verify_data.get("Measurement Mode"),
                    "Column selection": {
                        "enabled": self.verify_data.get("Use Column Selection") == "yes",
                        "energy": self.verify_data.get("QC Energy Column"),
                        "signal_a": self.verify_data.get("QC Signal A"),
                        "signal_b": self.verify_data.get("QC Signal B"),
                        "formula": self.verify_data.get("QC Formula"),
                    },
                    #"Energy": "None", # actual value
                    #"EnergyColumn": self.verify_data.get("Energy Column"), # description
                    #"Mu": "None", # actual value
                    #"MuColumn": self.verify_data.get("Mu Column"), # description
                    #"I_zero": "None", # actual value
                    #"I_zeroColumn": self.verify_data.get("I0 Column"), # description
                    #"Transmission": "None", # actual value
                    #"TransmissionColumn": self.verify_data.get("Transmission Column"), # description
                },
                "RAW": {
                    "edge_step": {
                        "value": 0.0,
                        "unit": "a.u.",
                        "documentation": "Height of the detected edge step.",
                    },
                    "k_max": {
                        "value": 0.0,
                        "unit": "\u212B\u207B\u00B9",
                        "documentation": "Considered angular wavenumber.",
                    },
                    "energy_resolution": {
                        "value": 0.0,
                        "unit": "eV",
                        "documentation": "Energy resolution of the measured spectrum in eV.",
                    },
                    "noise": {
                        "value": 0.0,
                        "unit": "a.u.",
                        "documentation": "Noise of the measurement.",
                    },
                },
                "PROCESSED": {
                    "amplitude_reduction_factor": {
                        "Z_ranges": {
                            "tentoforty": {
                                "value": 0.0,
                            },
                            "fortytoeighty": {
                                "value": 0.0,
                            },
                        },
                        "unit": "a.u.",
                        "documentation": "amplitude factor from the processed spectrum",
                    }
                },
                "Figures": {
                    "raw_data": None,
                    "normalized_data": None,
                    "k": None,
                    "R": None,
                },
                "sample_info": {
                    "coll_code": self.verify_data.get("Coll.code"),
                    "physical_state": self.verify_data.get("Phys.state"),
                    "crystal_orientation": self.verify_data.get("Crystal orientation"),
                    "temperature": self.verify_data.get("Temperature"),
                    "pressure": self.verify_data.get("Pressure"),
                    "sample_environment": self.verify_data.get("Sample environment"),
                    "general_remarks": self.verify_data.get("General remarks"),
                    "sample_prep": self.verify_data.get("Sample preparation"),
                    "sample_id": self.verify_data.get("Sample ID"),
                },
                "instrument": {
                    "facility": self.verify_data.get("Facility"),
                    "beamline": self.verify_data.get("Beamline"),
                    "aquisition_mode": self.verify_data.get("Acq. mode"),
                    "crystals": self.verify_data.get("Crystals"),
                    "mirrors": self.verify_data.get("Mirrors"),
                    "detectors": self.verify_data.get("Detectors"),
                    "element_input": self.verify_data.get("Element"),
                    "edge_input": self.verify_data.get("Edge"),
                    "max_k_range": self.verify_data.get("Max k-range"),
                },
                "bibliography": {
                    "doi": self.verify_data.get("DOI"),
                    "reference": self.verify_data.get("Reference"),
                    "disclaimer": self.verify_data.get("DisclaimerVerification"),
                },
                "is_approved": False,
            },
            "keywords": "None",
        }

        with scicat_py.ApiClient(self.configuration) as api_client:
            api_client.configuration.access_token = self.access_token
            api_instance = scicat_py.DatasetsApi(api_client)
            create_dataset_dto = scicat_py.CreateDatasetDto(**self.data_dict)
            api_response = api_instance.datasets_controller_create(
                create_dataset_dto, async_req=False, _preload_content=False
            )
            self.resp = json.loads(api_response.data)
            print('ME RAW DATA:', self.resp)
            self.datasetId = self.resp["id"]
            print("ME DATASET ID:", self.datasetId)
            return self.datasetId

    def post_sthree(self) -> requests.Response:
        """
        Uploads a file to the S3 bucket and returns the response.

        Returns:
            requests.Response: The response from the server.

        Raises:
            FileNotFoundError: If the file specified by `self.s3_data_path` is not found.
        """
        try:
            values: Dict[str, Any] = {"dataset_id": self.datasetId}
            with open(self.s3_data_path, "rb") as source_file:
                self.responds = requests.post(
                    f"{XAFSDB_INTERNAL_URL.rstrip('/')}/{prefix}/{prefix}/",
                    files={"file": source_file},
                    data=values,
                    timeout=120,
                )
            self.responds.raise_for_status()
            # dev:
            #self.responds = requests.post(
            #    f"http://34.29.27.51/{prefix}/{prefix}/", files=files, data=values
            #)
            #print("I'm in sthree:", self.responds.json)
            return self.responds
        except FileNotFoundError as e:
            logging.exception(f"Could not upload file: {e}")
            raise

    def upload_selected_spectrum(self, data, column_selection) -> requests.Response:
        output = io.StringIO()
        output.write("# RefXAS selected QC spectrum\n")
        output.write(f"# energy_column: {column_selection.get('energy')}\n")
        output.write(f"# signal_a: {column_selection.get('signal_a')}\n")
        output.write(f"# signal_b: {column_selection.get('signal_b')}\n")
        output.write(f"# calculation: {column_selection.get('formula')}\n")
        output.write("energy,selected_spectrum\n")
        np.savetxt(output, np.column_stack((data[0], data[1])), delimiter=",")
        filename = f"{Path(self.data_set_name).stem}_selected_qc_spectrum.csv"
        response = requests.post(
            f"{XAFSDB_INTERNAL_URL.rstrip('/')}/{prefix}/{prefix}/",
            files={"file": (filename, output.getvalue().encode("utf-8"), "text/csv")},
            data={"dataset_id": self.datasetId},
            timeout=120,
        )
        response.raise_for_status()
        return response

    def short_url(self) -> str:
        """
        Generate a short URL for the current file.

        Note: creates folder and downloads the file.
        Param:
            cache_ttl=0
            Disables caching and prevents the creation of any cache directory.
            May affect the performance of the application.

        Returns:
            The generated short URL as a string.
        """
        #self.short_url = self.responds.json()["file"].split("?")[0]
        type_tiny = pyshorteners.Shortener()
        #print("I'm in short_url:", self.responds.status_code, self.responds.text)
        self.short_url = type_tiny.tinyurl.short(self.responds.json()["file"])

        return self.short_url

    def qc_and_update(self) -> NoReturn:
        """
        Performs quality control checks on newly uploaded dataset measurements, updates
        the dataset's scientific metadata with quality control results, and communicates
        these updates to the SciCat database. Additionally, it generates and stores plots
        for the dataset and notifies the curator about the new dataset via email.

        Attributes:
            configuration: Configuration settings for the SciCat API client.
            access_token: Auth token used for API requests.
            qc_path: Path to the directory containing the quality control criteria JSON.
            verify_data: Dictionary containing data verification details used in quality checks.
            s3_data_path: Path where the dataset's files are stored, used for processing.
            data_dict: Dictionary where processed data and metadata are stored and updated.

        Uses:
            This method processes the dataset using predefined quality criteria stored in a
            JSON file, updates the dataset's metadata based on the analysis results, and uploads
            the updated information along with generated plots to the SciCat database. If all
            quality checks are passed, it sends an email to notify the curator and updates the
            dataset entry in the database with quality metrics and plot data.

        Raises:
            Various exceptions related to file handling, data processing, or API communication
            failures could be raised implicitly within the method.

        Side effects:
            - Modifies `self.data_dict` with new scientific metadata.
            - Generates plot images and encodes them in base64 for storage.
            - Sends an email to the curator.
            - Updates the dataset in the SciCat database with new information.
        """
        with scicat_py.ApiClient(self.configuration) as api_client:
            api_client.configuration.access_token = self.access_token
            api_instance = scicat_py.DatasetsApi(api_client)

            ### CHECK QUALITY CONTROL ###
            ### loading the json criteria file for reference
            cq_json = (self.qc_path + "Criteria.json")
            ### initialize quality check object
            cq = check_quality(
                quality_criteria_json=cq_json,
                element=self.verify_data.get("Element") or None,
                edge=self.verify_data.get("Edge") or None,
            )
            qc_list = [] ### this list will contain the quality criteria
            ### here the measurement data has to be forwarded, where will the data be stored in SciCat?
            #meas_data = np.loadtxt(self.short_url, skiprows=1)
            column_selection = None
            if self.verify_data.get("Use Column Selection") == "yes":
                column_selection = {
                    "energy": self.verify_data.get("QC Energy Column"),
                    "signal_a": self.verify_data.get("QC Signal A"),
                    "signal_b": self.verify_data.get("QC Signal B"),
                    "formula": self.verify_data.get("QC Formula"),
                }
            rd = ReadData(
                source=self.data_dict["scientific_metadata"]["Data"]["Source"],
                update_erange=self.verify_data,
                column_selection=column_selection,
            )
            rd.process_data(self.s3_data_path)
            if column_selection:
                resolved_selection = rd.meta_data_dict.get(
                    "Column_selection", column_selection
                )
                self.data_dict["scientific_metadata"]["Data"]["Column selection"] = {
                    "enabled": True,
                    **resolved_selection,
                }
                self.upload_selected_spectrum(rd.data, resolved_selection)
            #print("Meas_data from qc_and_update:", meas_data)
            cq.load_data(
                rd.data,
                source=self.data_dict["scientific_metadata"]["Data"]["Source"],
                name=self.data_dict["dataset_name"],
            )
            ### perform preprocessing on the data
            data = cq.preprocess_data()
            self.data_dict["scientific_metadata"]["instrument"]["element_input"] = data.element_n_edge[0]
            self.data_dict["scientific_metadata"]["instrument"]["edge_input"] = data.element_n_edge[1]
            ### plot the data and return the figure object
            fig_raw_data = cq.plot_data(data_type = "RAW")
            fig_normalized_data = cq.plot_data(data_type = "NORMALIZED")
            fig_k = cq.plot_data(data_type = "k")  ### plot data in k and return the figure object
            fig_R = cq.plot_data(data_type = "R")  ### plot data in R and return the figure object
            self.data_dict["scientific_metadata"]["Figures"]["raw_data"] = cq.encode_base64_figure(fig_raw_data)
            self.data_dict["scientific_metadata"]["Figures"]["normalized_data"] = cq.encode_base64_figure(fig_normalized_data)
            self.data_dict["scientific_metadata"]["Figures"]["k"] = cq.encode_base64_figure(fig_k)
            self.data_dict["scientific_metadata"]["Figures"]["R"] = cq.encode_base64_figure(fig_R)
            ### check for the edge step
            qc_list.append(cq.check_edge_step())
            ### add to data_dict
            self.data_dict["scientific_metadata"]["RAW"]["edge_step"]["value"] = np.round(qc_list[0][1], decimals = 3)
            ### check for the energy resolution
            qc_list.append(cq.check_energy_resolution())
            ### add to data_dict
            self.data_dict["scientific_metadata"]["RAW"]["energy_resolution"]["value"] = np.round(qc_list[1][1], decimals = 1)
            ### check for k
            qc_list.append(cq.check_k())
            ### add to data_dict
            self.data_dict["scientific_metadata"]["RAW"]["k_max"]["value"] = np.round(qc_list[2][1], decimals = 1)
            ### Hand over quality criteria to webserver
            self.edge_step = self.data_dict["scientific_metadata"]["RAW"]["edge_step"]["value"]
            self.energy_res = self.data_dict["scientific_metadata"]["RAW"]["energy_resolution"]["value"]
            self.k_max = self.data_dict["scientific_metadata"]["RAW"]["k_max"]["value"]
            #self.noise = self.data_dict["scientific_metadata"]["RAW"]["noise"]["value"]
            if all(qc_list):
                print("DO SERVER COMMUNICATION -> CREATE DATASET")
                api_response = api_client.call_api(
                    "/api/v3/datasets/{id}",
                    "PATCH",
                    {"id": self.datasetId},
                    [],
                    {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                    },
                    body={
                        "sourceFolder": self.short_url,
                        "keywords": [self.edge_step, self.k_max, self.energy_res],
                        "scientificMetadata": self.data_dict["scientific_metadata"],
                    },
                    post_params=[],
                    files={},
                    response_type="object",
                    auth_settings=["bearer"],
                    _return_http_data_only=False,
                )
                response = api_response[0]
                self.data_dict["scientific_metadata"]["Figures"]["raw_data"]
                self.data_dict["scientific_metadata"]["Figures"]["normalized_data"]
                self.data_dict["scientific_metadata"]["Figures"]["k"]
                self.data_dict["scientific_metadata"]["Figures"]["R"]

                # Curator notification is intentionally kept with the original
                # subject, body and recipients. The notification is controlled
                # by EMAIL_NOTIFICATIONS_ENABLED so local development can skip
                # SMTP while the KIT VM can enable it through environment config.
                # A notification failure must not invalidate an already-created
                # and successfully updated SciCat dataset.
                logger = logging.getLogger(__name__)
                if EMAIL_NOTIFICATIONS_ENABLED:
                    try:
                        print("SENDING MESSAGE TO CURATOR...")
                        send_mail('RefXAS: NEW DATASET CREATED',
                                  'HEY MATE! \n\nSOMETHING EXCITING HAS HAPPENED: A NEW DATASET HAS BEEN CREATED! \nGO AND CURATE IT ASAP! \n\nSTAY HANDSOME :D'
                                  + "\n\nPayload-preview:" + "\n\nDATASET NAME:" + str(self.data_set_name) + "\n\nOWNER:" + str(self.resp["owner"]),
                                  EMAIL_HOST_USER, [EMAIL_HOST_USER, 'abhijeet.gaur@kit.edu'])
                    except Exception:
                        logger.exception(
                            "Dataset %s was created successfully, but curator notification failed.",
                            self.datasetId,
                        )
                else:
                    logger.info(
                        "Curator email notification disabled for dataset %s",
                        self.datasetId,
                    )

    def upload_figure_data(self, figure: str, caption: Optional[str]="") -> None:
        """
        Uploads a figure to the SciCat API as an attachment for a specific dataset.

        Args:
            figure (str): The figure data as a base64-encoded string.
            caption (str, optional): An optional caption for the figure attachment.

        Raises:
            ApiException: If there was an error while uploading the figure data.
        """
        QC_attach_figure_data = {
            "thumbnail": figure,
            "caption": caption,
            "access_groups": "None",
            "created_by": "string",
            "updated_by": "string",
            "owner_group": "some group",
        }
        with scicat_py.ApiClient(self.configuration) as api_client:
            api_client.configuration.access_token = self.access_token
            api_instance = scicat_py.DatasetsApi(api_client)
            create_attachment_dto = scicat_py.CreateAttachmentDto(**QC_attach_figure_data)
            api_response = api_instance.datasets_controller_create_attachment(
                self.datasetId,
                create_attachment_dto,
                async_req=False,
                _preload_content=False,
            )
            response = json.loads(api_response.data)
