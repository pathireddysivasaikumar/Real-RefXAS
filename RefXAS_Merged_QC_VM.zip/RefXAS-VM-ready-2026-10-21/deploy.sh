#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

required_files=(
  .env
  xafsdb_deployment/config/backend/config.env
  xafsdb_deployment/config/backend/functionalAccounts.json
  xafsdb_deployment/config/xafsdb/_auth_constants.py
)

for required_file in "${required_files[@]}"; do
  if [[ ! -f "$required_file" ]]; then
    echo "Missing $required_file. Follow README_VM_DEPLOYMENT.md before deployment."
    exit 1
  fi
done

if grep -R "CHANGE_ME" "${required_files[@]}" >/dev/null; then
  echo "Deployment stopped: one or more CHANGE_ME placeholders remain."
  exit 1
fi

docker compose --env-file .env \
  -f xafsdb_deployment/docker-compose.yaml config --quiet
docker compose --env-file .env \
  -f xafsdb_deployment/docker-compose.yaml build xafsdb
docker compose --env-file .env \
  -f xafsdb_deployment/docker-compose.yaml up -d
docker compose --env-file .env \
  -f xafsdb_deployment/docker-compose.yaml ps
