"""Run the original RefXAS quality control on local measurement files."""

import argparse
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from quality_control.quality_check import CheckQualityControl


SUPPORTED_EXTENSIONS = {"", ".dat", ".xdi", ".txt", ".csv", ".spec", ".h5", ".hdf", ".hdf5"}
FIELDS = [
    "file", "status", "approved", "edge_step_pass", "edge_step",
    "energy_resolution_pass", "energy_resolution_ev", "k_max_pass", "k_max",
    "noise_pass", "noise", "error",
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Measurement file or folder containing measurement files")
    parser.add_argument("--output", type=Path, default=Path("results"), help="Results folder (default: results)")
    parser.add_argument("--facility", choices=("SYNCHROTRON", "LABORATORY"), default="SYNCHROTRON")
    parser.add_argument("--take-first", action="store_true", help="Use the first derivative peak for E0")
    parser.add_argument("--no-plots", action="store_true", help="Skip PNG plot generation")
    args = parser.parse_args()

    input_path = args.input.expanduser().resolve()
    if input_path.is_file():
        files = [input_path]
    elif input_path.is_dir():
        files = sorted(path for path in input_path.iterdir()
                       if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS)
    else:
        parser.error(f"Input does not exist: {input_path}")
    if not files:
        parser.error("No supported measurement files found")

    output_path = args.output.expanduser().resolve()
    output_path.mkdir(parents=True, exist_ok=True)
    if not args.no_plots:
        for folder in ("RAW", "NORMALIZED", "k", "R"):
            (output_path / folder).mkdir(exist_ok=True)

    rows = []
    for file_path in files:
        row = dict.fromkeys(FIELDS, "")
        row["file"] = str(file_path)
        try:
            qc = CheckQualityControl(
                facility_type=args.facility,
                files=[file_path],
                plot_raw_data=not args.no_plots,
                plot_normalized_data=not args.no_plots,
                plot_k=not args.no_plots,
                plot_R=not args.no_plots,
                save_figure_path=str(output_path) if not args.no_plots else None,
                take_first=args.take_first,
                verbose=False,
            )
            checks = qc.qc_list
            row.update({
                "status": "processed",
                "approved": all(bool(check[0]) for check in checks),
                "edge_step_pass": bool(checks[0][0]),
                "edge_step": checks[0][1],
                "energy_resolution_pass": bool(checks[1][0]),
                "energy_resolution_ev": checks[1][1],
                "k_max_pass": bool(checks[2][0]),
                "k_max": checks[2][1],
                "noise_pass": bool(checks[3][0]),
                "noise": checks[3][1],
            })
            print(f"{file_path.name}: {'APPROVED' if row['approved'] else 'REVIEW'}")
        except Exception as error:
            row["status"] = "error"
            row["error"] = f"{type(error).__name__}: {error}"
            print(f"{file_path.name}: ERROR - {row['error']}")
        finally:
            plt.close("all")
        rows.append(row)

    summary = output_path / "qc_summary.csv"
    with summary.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Summary: {summary}")
    return 1 if any(row["status"] == "error" for row in rows) else 0


if __name__ == "__main__":
    raise SystemExit(main())
