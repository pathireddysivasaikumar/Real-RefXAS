import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import h5py
import tempfile
from larch import xray

from auto_dataset_create import AutoDatasetCreation
from plugins.read_data import ReadData
from quality_control.quality_check import CheckQuality, CheckQualityControl


ROOT = Path(__file__).resolve().parents[1]
CRITERIA = ROOT / "quality_control" / "Criteria.json"


class SelectedSpectrumExportTests(unittest.TestCase):
    def test_selected_spectrum_csv_contains_traceability_header(self):
        creator = AutoDatasetCreation.__new__(AutoDatasetCreation)
        creator.data_set_name = "NiO_ref_0001.dat"
        creator.datasetId = "dataset-1"
        data = np.array([
            [8300.0, 8301.0],
            [0.1, 0.2],
            [0.3, 0.4],
        ])
        selection = {
            "energy": "position",
            "signal_a": "i1",
            "signal_b": "i2",
            "formula": "log_ratio",
        }
        response = SimpleNamespace(raise_for_status=lambda: None)

        with patch("auto_dataset_create.requests.post", return_value=response) as post:
            creator.upload_selected_spectrum(data, selection)

        file_tuple = post.call_args.kwargs["files"]["file"]
        self.assertEqual(file_tuple[0], "NiO_ref_0001_selected_qc_spectrum.csv")
        csv_text = file_tuple[1].decode("utf-8")
        self.assertIn("# energy_column: position", csv_text)
        self.assertIn("# signal_a: i1", csv_text)
        self.assertIn("# signal_b: i2", csv_text)
        self.assertIn("# calculation: log_ratio", csv_text)
        self.assertIn("energy,selected_spectrum", csv_text)
        self.assertIn("8.300000000000000000e+03,1.000000000000000056e-01", csv_text)
        self.assertEqual(post.call_args.kwargs["data"], {"dataset_id": "dataset-1"})


class BeamlineRecognitionTests(unittest.TestCase):
    def test_single_space_headers(self):
        examples = (
            ("SYNCHROTRON", "## 0 - Position", "PETRA III Extension Beamline P64"),
            ("SYNCHROTRON", "# Energy, Theta, XMU, FLUO, REF, FLUO_RAW, I0, I1, I2, I3", "SOLEIL SAMBA"),
            ("SYNCHROTRON", "# C Acquisition started", "SOLARIS"),
            ("SYNCHROTRON", "# created:", "DELTA"),
            ("LABORATORY", "# Energies_eV", "TU Berlin"),
        )
        for source, header, expected in examples:
            with self.subTest(expected=expected):
                reader = ReadData(source=source)
                reader.data_path = Path("example.dat")
                fake_data = SimpleNamespace(header=[header], data=np.ones((4, 3)))
                with patch("plugins.read_data.read_ascii", return_value=fake_data), \
                        patch.object(reader, "extract_header"), \
                        patch.object(reader, "load_data"):
                    reader.read_out_file()
                self.assertEqual(reader.beamline, expected)
                self.assertEqual(reader.source, source)

    def test_unknown_multicolumn_file_fails_closed(self):
        reader = ReadData()
        reader.data_path = Path("unknown.dat")
        fake_data = SimpleNamespace(header=["# unknown"], data=np.ones((4, 3)))
        with patch("plugins.read_data.read_ascii", return_value=fake_data):
            with self.assertRaisesRegex(ValueError, "Unrecognized beamline"):
                reader.read_out_file()

    def test_real_tu_berlin_file(self):
        reader = ReadData()
        reader.process_data(ROOT / "quality_control" / "example data" / "LABORATORY" / "CoO powder.dat")
        self.assertEqual(reader.beamline, "TU Berlin")
        self.assertEqual(reader.source, "LABORATORY")
        self.assertEqual(reader.data.shape[0], 3)

    def test_real_samba_file(self):
        reader = ReadData()
        reader.process_data(
            ROOT / "quality_control" / "example data" / "SYNCHROTRON"
            / "not_yet_working" / "Pt_foil Pt L3 SAMBA Soleil.txt"
        )
        self.assertEqual(reader.beamline, "SOLEIL SAMBA")
        self.assertEqual(reader.data.shape[0], 3)

    def test_manual_column_selection_is_applied(self):
        reader = ReadData(column_selection={
            "energy": "energy",
            "signal_a": "i1",
            "signal_b": "i2",
            "formula": "ratio",
        })
        reader.larch_data = SimpleNamespace(
            array_labels=["energy", "i1", "i2"],
            data=np.array([
                np.linspace(7000, 7019, 20),
                np.linspace(20, 39, 20),
                np.linspace(10, 29, 20),
            ]),
        )
        reader.apply_column_selection()
        np.testing.assert_allclose(
            reader.larch_data.mu_ref,
            reader.larch_data.data[1] / reader.larch_data.data[2],
        )
        self.assertEqual(reader.meta_data_dict["Column_selection"]["energy"], "energy")

    def test_nexus_hdf5_with_p64_channels(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            file_path = Path(temporary_directory) / "p64_scan.nxs"
            energy = np.linspace(11.5, 12.5, 100)
            i0 = np.full(100, 1000.0)
            i1 = i0 * np.exp(-np.linspace(0.2, 1.2, 100))
            i2 = i1 * np.exp(-np.linspace(0.1, 0.8, 100))
            with h5py.File(file_path, "w") as hdf_file:
                entry = hdf_file.create_group("entry")
                entry.attrs["beamline"] = "PETRA III P64"
                measurement = entry.create_group("measurement")
                measurement.create_dataset("energy", data=energy)
                measurement.create_dataset("I0", data=i0)
                measurement.create_dataset("I1", data=i1)
                measurement.create_dataset("I2", data=i2)

            reader = ReadData()
            reader.process_data(file_path)
            self.assertEqual(reader.beamline, "PETRA III Extension Beamline P64")
            self.assertEqual(reader.data.shape, (3, 100))
            self.assertGreater(reader.data[0, 0], 10000)

    def test_p64_spaced_hash_header_and_numbered_columns(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            file_path = Path(temporary_directory) / "p64_reference.dat"
            energy = np.linspace(8300, 8400, 20)
            i0 = np.full(20, 1000.0)
            i1 = i0 * np.exp(-0.4)
            i2 = i1 * np.exp(-0.2)
            rows = np.column_stack((energy, i0, i1, i2, np.ones(20), np.ones(20)))
            with file_path.open("w", encoding="utf-8") as data_file:
                data_file.write("# # 0 - Position\n# # 1 - i0\n# # 2 - i1\n")
                data_file.write("# # 3 - i2\n# # 4 - ipips\n# # 5 - exposure time\n#\n")
                np.savetxt(data_file, rows)

            reader = ReadData()
            reader.process_data(file_path)
            self.assertEqual(reader.beamline, "PETRA III Extension Beamline P64")
            self.assertEqual(reader.larch_data.array_labels[:4], ["position", "i0", "i1", "i2"])
            np.testing.assert_allclose(reader.data[1], 0.2)
            np.testing.assert_allclose(reader.data[2], 0.4)

    def test_extensionless_hdf5_is_detected_by_signature(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            file_path = Path(temporary_directory) / "p64_scan"
            with h5py.File(file_path, "w") as hdf_file:
                measurement = hdf_file.create_group("measurement")
                measurement.create_dataset("energy", data=np.linspace(7000, 7100, 50))
                measurement.create_dataset("mu", data=np.linspace(0, 1, 50))

            reader = ReadData()
            reader.process_data(file_path)
            self.assertEqual(reader.data.shape, (3, 50))


class EdgeSelectionTests(unittest.TestCase):
    def test_full_qc_uses_correct_iron_edge(self):
        file_path = ROOT / "quality_control" / "example data" / "SYNCHROTRON" / "Fe_foil_Fe_K_300.xdi"
        qc = CheckQualityControl(facility_type="SYNCHROTRON", files=[file_path])
        self.assertEqual(qc.data.element_n_edge, ("Fe", "K"))
        self.assertAlmostEqual(qc.data.E_difference, 0, delta=5)
        self.assertEqual(len(qc.qc_list), 4)

    def test_reference_foil_auto_selection(self):
        examples = (
            ("Fe_foil_Fe_K_300.xdi", ("Fe", "K")),
            ("Cu_foil_Cu_K_0000.xdi", ("Cu", "K")),
            ("Au foil_Au L3 P65 DESY.xdi", ("Au", "L3")),
            ("Pt_foil_Pt_L3_330.xdi", ("Pt", "L3")),
            ("Mo_foil_Mo_K_300.xdi", ("Mo", "K")),
        )
        folder = ROOT / "quality_control" / "example data" / "SYNCHROTRON"
        for filename, expected in examples:
            with self.subTest(filename=filename):
                reader = ReadData()
                reader.process_data(folder / filename)
                check = CheckQuality(CRITERIA)
                e0 = check.find_e0(reader.data[0], reader.data[1])
                self.assertEqual(xray.guess_edge(e0), expected)

    def test_automatic_e0_uses_strongest_derivative(self):
        energy = np.linspace(0, 100, 501)
        absorption = 1 / (1 + np.exp(-(energy - 30)))
        absorption += 0.4 / (1 + np.exp(-(energy - 70)))
        check = CheckQuality(CRITERIA)
        self.assertAlmostEqual(check.find_e0(energy, absorption), 30, delta=1)

    def test_manual_edge_must_match_energy(self):
        reader = ReadData()
        reader.process_data(ROOT / "quality_control" / "example data" / "SYNCHROTRON" / "Fe_foil_Fe_K_300.xdi")
        check = CheckQuality(CRITERIA, element="Fe", edge="K")
        check.load_data(reader.data)
        check.preprocess_data()
        self.assertEqual(check.data.element_n_edge, ("Fe", "K"))

        wrong_edge = CheckQuality(CRITERIA, element="As", edge="K")
        wrong_edge.load_data(reader.data.copy())
        with self.assertRaisesRegex(ValueError, "over 100 eV"):
            wrong_edge.preprocess_data()


if __name__ == "__main__":
    unittest.main()
